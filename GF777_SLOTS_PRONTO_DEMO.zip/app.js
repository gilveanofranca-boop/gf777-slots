let balance=100000,plays=0,score=0,currentGame='';
const symbols=['7','★','♦','🍋','🍒','🔔'];
function money(n){return Math.floor(n).toLocaleString('pt-BR')}
function openGame(name){currentGame=name;document.getElementById('gameName').textContent=name;document.getElementById('result').textContent='Escolha seus créditos virtuais e gire.';document.getElementById('gameModal').classList.add('open')}
function openModal(id){document.getElementById(id).classList.add('open')}
function closeModal(){document.querySelectorAll('.modal').forEach(x=>x.classList.remove('open'))}
function spin(){
 const bet=Math.max(10,Number(document.getElementById('bet').value)||100);
 if(bet>balance){document.getElementById('result').textContent='Créditos virtuais insuficientes.';return}
 balance-=bet; plays++;
 const reels=[0,0,0].map(()=>symbols[Math.floor(Math.random()*symbols.length)]);
 document.querySelectorAll('#reels span').forEach((x,i)=>x.textContent=reels[i]);
 let prize=0;
 if(reels[0]===reels[1]&&reels[1]===reels[2]) prize=bet*10;
 else if(reels[0]===reels[1]||reels[1]===reels[2]||reels[0]===reels[2]) prize=bet*2;
 balance+=prize; score+=prize?prize:10;
 document.getElementById('result').textContent=prize?`🎉 Combinação! +${money(prize)} créditos virtuais`:`Sem combinação — tente novamente.`;
 update();
}
function update(){document.getElementById('balance').textContent=money(balance);document.getElementById('balance2').textContent=money(balance);document.getElementById('plays').textContent=plays;document.getElementById('score').textContent=money(score)}
function showToast(msg){closeModal();const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),1800)}
update();