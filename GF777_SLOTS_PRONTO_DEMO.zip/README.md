# GF777 SLOTS — versão pronta para hospedagem (demo)
1. Extraia o ZIP.
2. Envie `index.html`, `styles.css` e `app.js` para a pasta pública do seu hosting.
3. Abra o domínio.

Não requer banco de dados ou Node.js nesta versão.
Os jogos são demonstrativos e usam somente créditos virtuais sem valor monetário.
Não inclui depósitos, saques, pagamentos ou apostas reais.
